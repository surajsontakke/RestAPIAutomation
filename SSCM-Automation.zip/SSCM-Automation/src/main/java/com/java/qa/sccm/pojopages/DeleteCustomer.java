package com.java.qa.sccm.pojopages;

public class DeleteCustomer {

	private String customer_id = "string";

	public String getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}

}
